//
//  ViewController.m
//  ZKBannertip
//
//  Created by zhangkeqin on 2025/6/5.
//

#import "ViewController.h"
#import "ZKBannerTipView.h"
// 屏幕宽高
#define Screen_Width [UIScreen mainScreen].bounds.size.width
#define Screen_Height [UIScreen mainScreen].bounds.size.height
@interface ViewController ()

@property (nonatomic, strong) UIButton *successButton;

@property (nonatomic, strong) UIButton *errorButton;

@property (nonatomic, strong) UIButton *warningButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configUI];
}

-(void)configUI{
    [self.view addSubview:self.successButton];
    [self.view addSubview:self.errorButton];
    [self.view addSubview:self.warningButton];
}


-(UIButton *)successButton{
    if(!_successButton){
        _successButton = [[UIButton alloc]initWithFrame:CGRectMake((Screen_Width - 300) / 2, 150, 300, 50)];
        _successButton.backgroundColor = [UIColor colorWithRed:0x2B/255.0 green:0x99/255.0 blue:0x45/255.0 alpha:1.0];
        [_successButton setTitle:@"成功" forState:UIControlStateNormal];
        [_successButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _successButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
        [_successButton addTarget:self action:@selector(successButtonAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _successButton;
}


-(UIButton *)errorButton{
    if(!_errorButton){
        _errorButton = [[UIButton alloc]initWithFrame:CGRectMake((Screen_Width - 300) / 2, CGRectGetMaxY(self.successButton.frame) + 30, 300, 50)];
        _errorButton.backgroundColor = [UIColor colorWithRed:0xE5/255.0 green:0x3D/255.0 blue:0x2F/255.0 alpha:1.0];
        [_errorButton setTitle:@"错误" forState:UIControlStateNormal];
        [_errorButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _errorButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
        [_errorButton addTarget:self action:@selector(errorButtonButtonAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _errorButton;
}



-(UIButton *)warningButton{
    if(!_warningButton){
        _warningButton = [[UIButton alloc]initWithFrame:CGRectMake((Screen_Width - 300) / 2, CGRectGetMaxY(self.errorButton.frame) + 30, 300, 50)];
        _warningButton.backgroundColor = [UIColor colorWithRed:0xFB/255.0 green:0xB6/255.0 blue:0x1A/255.0 alpha:1.0];
        [_warningButton setTitle:@"警告" forState:UIControlStateNormal];
        [_warningButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _warningButton.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
        [_warningButton addTarget:self action:@selector(warningButtonButtonAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _warningButton;
}

#pragma mark - 成功
-(void)successButtonAction{
    [[ZKBannerTipView sharedView] showMessage:@"文件保存成功，请注意查收" type:ZKBannerTipTypeSuccess duration:3 enableTapDismiss:NO];
}

#pragma mark - 错误
-(void)errorButtonButtonAction{
    [[ZKBannerTipView sharedView] showMessage:@"未知错误，请检查网络连接" type:ZKBannerTipTypeError duration:3 enableTapDismiss:NO];
}

#pragma mark - 警告
-(void)warningButtonButtonAction{
    [[ZKBannerTipView sharedView] showMessage:@"警告：当前操作存在风险" type:ZKBannerTipTypeWarning duration:3 enableTapDismiss:NO];
}

@end
