//
//  SceneDelegate.h
//  ZKBannertip
//
//  Created by zhangkeqin on 2025/6/5.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

