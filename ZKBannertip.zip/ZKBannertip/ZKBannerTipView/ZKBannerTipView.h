//
//  ZKBannerTipView.h
//  PalmBeiT
//
//  Created by ChatGPT on 2025/06/04.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, ZKBannerTipType) {
    ZKBannerTipTypeSuccess, // 绿色背景
    ZKBannerTipTypeError,   // 红色背景
    ZKBannerTipTypeWarning  // 黄色背景
};

@interface ZKBannerTipView : UIView

/// 单例，获取共享实例
+ (instancetype)sharedView;

/// 显示提示视图（自动计算高度，自动避让刘海，阻止全屏交互，默认不开启点击关闭）
/// @param message 提示文本
/// @param type 提示类型（成功、错误、警告）
- (void)showMessage:(NSString *)message
               type:(ZKBannerTipType)type;

/// 显示提示视图，并指定自动消失时间，是否允许点击空白关闭
/// @param message 提示文本
/// @param type 提示类型（成功、错误、警告）
/// @param duration 自动消失的时间（单位秒，<= 0 表示不自动消失）
/// @param enableTapDismiss 是否允许点击空白关闭，YES则点击背景任意空白处立即关闭提示视图
- (void)showMessage:(NSString *)message
               type:(ZKBannerTipType)type
           duration:(NSTimeInterval)duration
   enableTapDismiss:(BOOL)enableTapDismiss;

@end

NS_ASSUME_NONNULL_END
