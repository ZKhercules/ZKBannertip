#import "ZKBannerTipView.h"

@interface ZKBannerTipView ()

@property (nonatomic, strong) UILabel *messageLabel;
@property (nonatomic, strong) UIView *backgroundContainerView;
@property (nonatomic, strong) UIView *blockingView;
@property (nonatomic, assign) NSTimeInterval dismissDuration;
@property (nonatomic, assign) BOOL tapDismissEnabled;

@end

@implementation ZKBannerTipView

#pragma mark - 单例实现

+ (instancetype)sharedView {
    static ZKBannerTipView *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] initWithFrame:[UIScreen mainScreen].bounds];
    });
    return instance;
}

#pragma mark - 初始化

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // 阻挡交互的透明遮罩
        _blockingView = [[UIView alloc] initWithFrame:self.bounds];
        _blockingView.backgroundColor = [UIColor clearColor];
        [self addSubview:_blockingView];

        // 容器视图
        _backgroundContainerView = [[UIView alloc] init];
        _backgroundContainerView.clipsToBounds = YES;
        [self addSubview:_backgroundContainerView];

        // 提示文字
        _messageLabel = [[UILabel alloc] init];
        _messageLabel.numberOfLines = 0;
        _messageLabel.textAlignment = NSTextAlignmentCenter;
        _messageLabel.textColor = [UIColor whiteColor];
        _messageLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightBold];
        [_backgroundContainerView addSubview:_messageLabel];
    }
    return self;
}

#pragma mark - 弹出提示
- (void)showMessage:(NSString *)message
               type:(ZKBannerTipType)type {
    [self showMessage:message type:type duration:2.0 enableTapDismiss:NO];
}


- (void)showMessage:(NSString *)message
               type:(ZKBannerTipType)type
           duration:(NSTimeInterval)duration
   enableTapDismiss:(BOOL)enableTapDismiss {
    
    // 如果已存在于父视图中，先移除（确保只显示一个）
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(dismiss) object:nil];
    [self removeFromSuperview];

    self.dismissDuration = duration;
    self.tapDismissEnabled = enableTapDismiss;

    // 更新颜色和内容
    _messageLabel.text = message;
    _backgroundContainerView.backgroundColor = [self backgroundColorForType:type];

    // 添加点击手势
    [_blockingView.gestureRecognizers makeObjectsPerformSelector:@selector(removeFromSuperview)];
    if (enableTapDismiss) {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismiss)];
        [_blockingView addGestureRecognizer:tap];
    }

    [self setupLayout];

    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    if (!window) return;
    [window addSubview:self];

    [self show];
}

#pragma mark - 设置布局

- (void)setupLayout {
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    CGFloat screenWidth = [UIScreen mainScreen].bounds.size.width;
    CGFloat safeTop = window.safeAreaInsets.top;
    CGFloat padding = 16;
    CGFloat maxLabelWidth = screenWidth - padding * 2;

    CGSize labelSize = [_messageLabel sizeThatFits:CGSizeMake(maxLabelWidth, CGFLOAT_MAX)];
    CGFloat contentHeight = labelSize.height + padding * 2 + safeTop;

    _backgroundContainerView.frame = CGRectMake(0, -contentHeight, screenWidth, contentHeight);
    _messageLabel.frame = CGRectMake(padding, safeTop + padding, maxLabelWidth, labelSize.height);
}

#pragma mark - 显示动画

- (void)show {
    CGFloat finalY = 0;
    CGRect finalFrame = _backgroundContainerView.frame;
    finalFrame.origin.y = finalY;

    [UIView animateWithDuration:0.25 animations:^{
        self.backgroundContainerView.frame = finalFrame;
    } completion:^(BOOL finished) {
        if (self.dismissDuration > 0) {
            [self performSelector:@selector(dismiss) withObject:nil afterDelay:self.dismissDuration];
        }
    }];
}

#pragma mark - 关闭动画

- (void)dismiss {
    CGRect offscreenFrame = self.backgroundContainerView.frame;
    offscreenFrame.origin.y = -offscreenFrame.size.height;

    [UIView animateWithDuration:0.3 animations:^{
        self.backgroundContainerView.frame = offscreenFrame;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

#pragma mark - 背景色

- (UIColor *)backgroundColorForType:(ZKBannerTipType)type {
    switch (type) {
        case ZKBannerTipTypeSuccess:
            return [UIColor colorWithRed:0x2B/255.0 green:0x99/255.0 blue:0x45/255.0 alpha:1.0]; // #2B9945
        case ZKBannerTipTypeError:
            return [UIColor colorWithRed:0xE5/255.0 green:0x3D/255.0 blue:0x2F/255.0 alpha:1.0]; // #E53D2F
        case ZKBannerTipTypeWarning:
            return [UIColor colorWithRed:0xFB/255.0 green:0xB6/255.0 blue:0x1A/255.0 alpha:1.0]; // #FBB61A
    }
}

@end
